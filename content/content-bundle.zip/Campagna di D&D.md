"Le Cronache di Eternia" è una campagna di Dungeons & Dragons 5e che vi porterà in un mondo ricco di avventure, misteri e magia. Esplorate il vasto continente di Eternia, un luogo di maestose città, paesaggi selvaggi e antiche rovine.

In questa campagna, i giocatori avranno l'opportunità di immergersi in una storia epica, popolata da una varietà di razze, come elfi, nani, umani, gnomi e molte altre. Scoprite le tradizioni e le culture di questi popoli, interagendo con una vasta gamma di personaggi e affrontando sfide che metteranno alla prova le vostre abilità e l'astuzia.

Nel mondo di Eternia, il destino dell'intero continente è in bilico. Oscure minacce si stagliano all'orizzonte e una setta misteriosa, nota come "L'Ordine dell'Oscuro", si insinua tra le ombre, minacciando l'equilibrio del mondo. I giocatori, nei panni degli eroi, dovranno scoprire la verità dietro questa setta e fermare la sua ascesa prima che sia troppo tardi.

La storia de "Le Cronache di Eternia" si sviluppa in base alle azioni dei giocatori. Ogni scelta che compirete e ogni sfida che affronterete avrà un impatto sul mondo di gioco. I vostri personaggi potranno plasmare il destino delle città, interagire con PNG che possono diventare alleati o nemici, e scoprire antichi segreti che cambieranno il corso degli eventi.

Preparatevi per un'avventura coinvolgente e affascinante in cui potrete esplorare luoghi magici, combattere creature mitiche e incontrare personaggi indimenticabili. La vostra immaginazione sarà la chiave per scoprire i segreti di Eternia e forgiare un leggendario destino.